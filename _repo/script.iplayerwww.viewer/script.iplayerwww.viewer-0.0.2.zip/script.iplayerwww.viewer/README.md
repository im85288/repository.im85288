
### Welcome to iPlayer WWW Viewer
** A video addon used in association with the official BBC iPlayer WWW kodi addon **

** Why should I use this?**

- Provides an app like experience for iPlayer
- Allows for searching on iPlayer


**Installation in Kodi**

Simply Install my repo linked below and you will constantly receive updates as they are made available

### Download my Repository

[ ![Download](https://dl.dropboxusercontent.com/u/4689286/download-button.png) ](https://dl.dropboxusercontent.com/u/4689286/repository.im85288-1.0.0.zip)


### Donations
If you like my work and would like to show some appreciation please make a small donation.

[ ![Download](https://az743702.vo.msecnd.net/cdn/kofi4.png?v=a|alt=Buy Me a Coffee)](https://ko-fi.com/A1064DC)